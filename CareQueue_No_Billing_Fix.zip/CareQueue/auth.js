(() => {
  const $ = (id) => document.getElementById(id);
  const cfg = window.CAREQUEUE_FIREBASE_CONFIG || {};
  const configured = Boolean(cfg.apiKey && !String(cfg.apiKey).includes('PASTE_'));
  let auth, db, mode = 'signin', handlingAuth = false;

  function showMsg(message) {
    const box = $('authMessage');
    if (!box) return;
    box.textContent = message;
    box.classList.remove('hidden');
  }

  function setMode(newMode) {
    mode = newMode;
    const registering = mode === 'register';
    $('signInTab').classList.toggle('active', !registering);
    $('registerTab').classList.toggle('active', registering);
    $('nameLabel').classList.toggle('hidden', !registering);
    $('fullName').required = registering;
    $('formTitle').textContent = registering ? 'Create patient account' : 'Sign in';
    $('formDesc').textContent = registering
      ? 'Register once to book and track your hospital queue.'
      : 'Welcome back. Continue to your queue.';
    $('authSubmit').innerHTML = (registering ? 'Create account' : 'Sign in') + ' <span>→</span>';
    $('authMessage').classList.add('hidden');
  }

  async function routeSignedInUser(user) {
    if (!user || handlingAuth) return;
    handlingAuth = true;
    try {
      const profileSnap = await db.collection('users').doc(user.uid).get();
      if (!profileSnap.exists) {
        showMsg('Your account profile is missing in Firestore. Ask the project owner to check users/' + user.uid + '.');
        handlingAuth = false;
        return;
      }
      const profile = profileSnap.data() || {};
      const role = profile.role;
      const params = new URLSearchParams(window.location.search);
      const wantsAdmin = params.get('next') === 'admin';
      if (wantsAdmin && role !== 'admin') {
        showMsg('This account is not an administrator. In Firestore, check users/' + user.uid + ' and set role to the string admin only for the approved staff account.');
        handlingAuth = false;
        return;
      }
      if (role === 'admin') {
        window.location.replace('admin.html');
      } else {
        window.location.replace('index.html');
      }
    } catch (error) {
      console.error('CareQueue role check failed:', error);
      showMsg('Could not verify your account in Firestore: ' + (error.message || error.code || 'unknown error') + '. Check Firestore rules and the users document.');
      handlingAuth = false;
    }
  }

  if (configured) {
    if (!firebase.apps.length) firebase.initializeApp(cfg);
    auth = firebase.auth();
    db = firebase.firestore();
    auth.onAuthStateChanged((user) => {
      if (user) routeSignedInUser(user);
    });
  } else {
    showMsg('Firebase setup is required. Open SETUP-GUIDE.md and add your web app configuration to firebase-config.js.');
  }

  $('signInTab').onclick = () => setMode('signin');
  $('registerTab').onclick = () => setMode('register');

  $('authForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!configured) {
      showMsg('Add your Firebase web configuration in firebase-config.js first.');
      return;
    }
    const email = $('email').value.trim();
    const password = $('password').value;
    const name = $('fullName').value.trim();
    const button = $('authSubmit');
    button.disabled = true;
    $('authMessage').classList.add('hidden');
    try {
      if (mode === 'register') {
        if (!name) throw new Error('Enter your full name.');
        const credential = await auth.createUserWithEmailAndPassword(email, password);
        await db.collection('users').doc(credential.user.uid).set({
          name,
          email,
          role: 'patient',
          createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        await credential.user.updateProfile({ displayName: name });
      } else {
        await auth.signInWithEmailAndPassword(email, password);
      }
      // onAuthStateChanged checks the Firestore role and routes the user.
    } catch (error) {
      console.error('CareQueue sign-in failed:', error);
      showMsg(error.message || error.code || 'Could not sign in. Please try again.');
      button.disabled = false;
    }
  });
})();
