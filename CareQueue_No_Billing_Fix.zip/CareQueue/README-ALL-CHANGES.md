# CareQueue updated code package

## Before starting
- `firebase-config.js` still contains placeholders. Copy the Web App config from Firebase Console > Project settings > General > Your apps into that file. Do not use service-account keys in browser code.
- These changes add a callable Cloud Function named `bookToken` to allocate token numbers on the server.
- Existing design files are preserved. `app.js` is rewritten to remove the tokenNumber temporal-dead-zone bug and clean up Firestore listeners.

## Deploy (on a computer with Node.js and Firebase CLI)
1. Install Node.js LTS and Firebase CLI (`npm install -g firebase-tools`).
2. Open a terminal in the `CareQueue` folder.
3. Run `firebase login` and `firebase use carequeue-997dc` (if prompted, add the project with `firebase use --add`).
4. Run `cd functions && npm install && cd ..`.
5. Publish rules: `firebase deploy --only firestore:rules`.
6. Deploy function: `firebase deploy --only functions:bookToken`.
7. Deploy site: `firebase deploy --only hosting`.
8. Open the hosted patient site and test using a test account. Check Firebase Functions logs if booking fails.

## Required Firebase setup
- Authentication > Sign-in method: enable Email/Password.
- Firestore Database must be created.
- Update `firebase-config.js` with real web config values from Project settings > Your apps.
- In Firestore, ensure the approved staff UID has `users/{UID}` document with `role` set to string `admin`.
- Do not make queueCounters or tokens publicly writable.

## Important notes
- Cloud Functions require Blaze billing. Charges may apply; configure a billing budget alert.
- Existing admin.js updates token statuses from the admin browser. These rules allow that only when the signed-in user has role `admin`.
- This is a student project starter, not a certified production clinical system. Use synthetic data only until a qualified review of security/privacy and hospital workflows.


## No-Cloud-Functions booking update
This package's patient booking flow uses a Firestore transaction and does not call the `bookToken` Cloud Function. After replacing the files, publish `firestore.rules` in Firebase Console > Firestore Database > Rules. This is a college presentation version only; client-side counter allocation is not suitable for a real hospital production system.
