(() => {
  const $ = (id) => document.getElementById(id);
  let auth, db, currentUser = null, patientUnsub = null, queueUnsub = null, activeToken = null;
  const cfg = window.CAREQUEUE_FIREBASE_CONFIG || {};
  const configured = Boolean(cfg.apiKey && !String(cfg.apiKey).includes('PASTE_') && cfg.projectId);

  function toast(message) {
    const el = $('toast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 3500);
  }

  function showError(prefix, error) {
    console.error(prefix, error);
    toast(`${prefix}: ${error?.message || error?.code || 'Please try again.'}`);
  }

  function stopQueueListener() {
    if (queueUnsub) { queueUnsub(); queueUnsub = null; }
  }

  function listenPatient(uid) {
    if (patientUnsub) patientUnsub();
    patientUnsub = db.collection('tokens').where('uid', '==', uid).onSnapshot((snapshot) => {
      const docs = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      const active = docs.filter((token) => ['waiting', 'serving', 'called'].includes(token.status));
      active.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
      activeToken = active[0] || null;
      if (!activeToken) {
        stopQueueListener();
        $('trackingCard').classList.add('hidden');
        $('signedOutTrack').classList.remove('hidden');
        $('heroToken').textContent = '—';
        $('heroWait').textContent = '— min';
        return;
      }
      $('trackingCard').classList.remove('hidden');
      $('signedOutTrack').classList.add('hidden');
      renderTracking(activeToken);
    }, (error) => showError('Could not load your tokens', error));
  }

  function renderTracking(token) {
    stopQueueListener();
    queueUnsub = db.collection('queuePublic').where('department', '==', token.department).onSnapshot((snapshot) => {
      const list = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }))
        .filter((item) => ['waiting', 'serving', 'called'].includes(item.status))
        .sort((a, b) => (a.createdAt?.seconds || 0) - (b.createdAt?.seconds || 0));
      const index = list.findIndex((item) => item.id === token.id);
      const ahead = token.status === 'serving' || token.status === 'called' ? 0 : Math.max(0, index - (list.some((item) => item.status === 'serving') ? 1 : 0));
      const minutesPerPatient = 10;
      const wait = token.status === 'serving' || token.status === 'called' ? 0 : ahead * minutesPerPatient;
      $('trackToken').textContent = token.tokenLabel || 'CQ—';
      $('trackStatus').textContent = token.status === 'serving' || token.status === 'called' ? 'Your turn' : 'Waiting';
      $('aheadCount').textContent = ahead;
      $('waitTime').textContent = `${wait} min`;
      $('queuePosition').textContent = token.status === 'serving' || token.status === 'called' ? 'Now' : Math.max(1, index + 1);
      $('heroToken').textContent = token.tokenNumber ?? '—';
      $('heroWait').textContent = `${wait} min`;
      $('trackProgress').style.width = (token.status === 'serving' || token.status === 'called' ? 100 : Math.min(95, Math.max(5, 100 / (index + 2)))) + '%';
      $('progressLabel').textContent = token.status === 'serving' || token.status === 'called' ? 'You are being called' : `${ahead} patient(s) ahead`;
      $('alertTitle').textContent = token.status === 'serving' || token.status === 'called' ? 'It is your turn' : ahead <= 2 ? 'Your turn is approaching' : 'You are in the queue';
      $('alertText').textContent = token.status === 'serving' || token.status === 'called' ? 'Please proceed to the reception/consultation area.' : `About ${wait} minutes estimated. Stay nearby and keep notifications enabled.`;
      if ((token.status === 'serving' || token.status === 'called') && 'Notification' in window && Notification.permission === 'granted' && window._notifiedToken !== token.id) {
        new Notification('CareQueue: It is your turn', { body: `Token ${token.tokenLabel}. Please proceed to ${token.department}.` });
        window._notifiedToken = token.id;
      }
    }, (error) => showError('Live queue updates failed', error));
  }

  if (configured) {
    if (!firebase.apps.length) firebase.initializeApp(cfg);
    auth = firebase.auth();
    db = firebase.firestore();
    auth.onAuthStateChanged(async (user) => {
      currentUser = user;
      if (!user) {
        $('authNotice').classList.remove('hidden');
        $('signedOutTrack').classList.remove('hidden');
        $('trackingCard').classList.add('hidden');
        if (patientUnsub) { patientUnsub(); patientUnsub = null; }
        stopQueueListener();
        return;
      }
      $('authNotice').classList.add('hidden');
      $('signedOutTrack').classList.add('hidden');
      $('trackingCard').classList.remove('hidden');
      try {
        const profile = await db.collection('users').doc(user.uid).get();
        $('patientName').value = (profile.exists && profile.data().name) || user.displayName || '';
      } catch (error) { showError('Could not load your profile', error); }
      listenPatient(user.uid);
    });
  } else {
    $('authNotice').textContent = 'Firebase setup is required. Add your Firebase Web App configuration in firebase-config.js.';
  }

  $('bookingForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!configured) { toast('Complete Firebase setup first in firebase-config.js.'); return; }
    if (!currentUser) { toast('Please sign in before booking a token.'); location.href = 'login.html'; return; }
    const name = $('patientName').value.trim();
    const department = $('department').value;
    const visitType = $('visitType').value;
    if (!name) { toast('Enter your name.'); return; }
    const button = event.submitter || $('bookingForm').querySelector('button[type="submit"]');
    if (button) button.disabled = true;
    try {
      // College-project version: allocate the next token in a Firestore transaction.
      // This avoids requiring paid Cloud Functions, but is not production-grade security.
      const safeDepartmentId = department.replace(/[^a-z0-9]/gi, '_');
      const counterRef = db.collection('queueCounters').doc(safeDepartmentId);
      const tokenRef = db.collection('tokens').doc();
      const publicRef = db.collection('queuePublic').doc(tokenRef.id);
      const allocation = await db.runTransaction(async (transaction) => {
        const counterSnapshot = await transaction.get(counterRef);
        const lastNumber = counterSnapshot.exists && Number.isInteger(counterSnapshot.data().lastNumber)
          ? counterSnapshot.data().lastNumber : 0;
        const nextNumber = lastNumber + 1;
        const nextLabel = `CQ-${String(nextNumber).padStart(3, '0')}`;
        const timestamp = firebase.firestore.FieldValue.serverTimestamp();
        transaction.set(counterRef, {
          lastNumber: nextNumber,
          department,
          updatedAt: timestamp
        }, { merge: true });
        transaction.set(tokenRef, {
          uid: currentUser.uid,
          patientName: name,
          department,
          visitType,
          tokenNumber: nextNumber,
          tokenLabel: nextLabel,
          status: 'waiting',
          createdAt: timestamp,
          serviceMinutes: 10
        });
        transaction.set(publicRef, {
          department,
          tokenNumber: nextNumber,
          tokenLabel: nextLabel,
          status: 'waiting',
          createdAt: timestamp
        });
        return { tokenNumber: nextNumber, tokenLabel: nextLabel };
      });
      const tokenNumber = allocation.tokenNumber;
      const tokenLabel = allocation.tokenLabel;
      $('bookingResult').classList.remove('hidden');
      $('bookingResult').innerHTML = `<span class="result-check">✓</span><div><b>Token booked successfully</b><p>Your token is <strong>${tokenLabel}</strong>. Open Track My Token to see your live position and wait estimate.</p></div>`;
      toast(`Token ${tokenLabel} booked successfully.`);
      $('track').scrollIntoView({ behavior: 'smooth' });
      if (currentUser) listenPatient(currentUser.uid);
    } catch (error) {
      showError('Booking failed', error);
    } finally {
      if (button) button.disabled = false;
    }
  });

  $('enableNotifications').addEventListener('click', async () => {
    if (!('Notification' in window)) { toast('This browser does not support notifications.'); return; }
    const permission = await Notification.requestPermission();
    toast(permission === 'granted' ? 'Notifications enabled while this site is open.' : 'Notification permission was not granted.');
  });
  $('signOut').addEventListener('click', () => auth?.signOut().then(() => location.href = 'login.html'));

  let scanner = null;
  $('showScanner').addEventListener('click', async () => {
    if (!window.Html5Qrcode) { toast('Scanner library could not load.'); return; }
    const reader = $('reader');
    reader.classList.toggle('hidden');
    if (!reader.classList.contains('hidden')) {
      try {
        scanner = new Html5Qrcode('reader');
        await scanner.start({ facingMode: 'environment' }, { fps: 10, qrbox: { width: 220, height: 220 } }, (text) => {
          if (scanner) scanner.stop().catch(() => {});
          if (/^https?:\/\//.test(text)) location.href = text;
          else toast('QR content: ' + text);
        }, () => {});
      } catch (error) { toast('Allow camera access and use HTTPS or localhost to scan.'); }
    } else if (scanner) scanner.stop().catch(() => {});
  });
})();
