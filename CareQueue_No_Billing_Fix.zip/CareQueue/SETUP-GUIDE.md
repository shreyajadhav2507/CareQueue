# CareQueue — Smart Hospital Queue Management

This is the website source package for CareQueue. The visible interface does not use the word “demo”. It is built for Firebase Authentication and Cloud Firestore, with separate patient, sign-in, and admin pages.

## Important before you present it

The site cannot connect to your Firebase project until you paste your Firebase **Web App config** into `firebase-config.js`, enable Email/Password Authentication, create Firestore, and publish the security rules. Do not claim that cross-device live updates or notifications are active until you test them on two devices/browsers.

## 1. Connect Firebase

1. Open Firebase Console and choose your CareQueue project.
2. Open **Project settings → General → Your apps**. Register a Web app if one does not exist.
3. Copy the Firebase web configuration values into `firebase-config.js`, replacing every `PASTE_...` value. The web config is not a service-account key; never put a service-account private key in website files.
4. In **Authentication → Sign-in method**, enable **Email/Password**.
5. In **Firestore Database**, create the database.
6. Open Firestore **Rules**, paste the contents of `firestore.rules`, and publish. Review rules for your institution before any real patient use.
7. Serve the folder using Firebase Hosting or another HTTPS static host. Camera scanning and browser notifications are restricted on many browsers unless the site is HTTPS or localhost.

## 2. Grant administrator access

1. Register your own account from `login.html`.
2. In Firebase Console → Firestore → `users`, find the document whose ID is your account's Firebase Auth UID.
3. Change its `role` field from `patient` to `admin` (string value `admin`). Do this only for the designated administrator account. Do not share that login.
4. Sign out and sign in again, then open `admin.html`. The admin console checks the role in Firestore and the rules also enforce admin-only operations.

## 3. Open the website

For a quick local check, open `index.html` in a browser. For camera QR scanning and reliable auth behavior, use a local server or HTTPS hosting. You can upload the folder to Firebase Hosting after running the standard Firebase Hosting setup on a computer with the Firebase CLI installed.

## 4. Test the core flow

1. Create two separate patient accounts in separate browser profiles/devices.
2. Book a token in the same department from both accounts.
3. Sign in as the administrator and open `admin.html`.
4. Select that department and use **Call next**, **Complete**, or **Skip**. Patient pages should reflect status changes through Firestore listeners.
5. Verify the displayed ahead count and wait estimate against the actual department queue.

## Included functionality

- Patient account creation and sign-in with Firebase Authentication.
- Token creation with a Firestore transaction-backed department counter.
- Department queue tracking and status updates through Firestore listeners.
- Patient queue position, people ahead, and a configurable admin estimate setting.
- Admin-only queue controls enforced by Firestore rules and the admin role.
- QR scanner entry point using the device camera where supported.
- Browser notification permission and in-page turn alerts.

## Requirements and limitations to resolve before real hospital use

- **Background push alerts:** this package currently requests browser notification permission and shows a notification while the patient site is open. True background push when the site is closed requires Firebase Cloud Messaging, a service worker, HTTPS, VAPID configuration, and a trusted server/Cloud Function to send messages. Do not rely on in-page notifications as a guaranteed off-site alert.
- **QR code generation:** the QR section explains the onboarding flow; generate and print a QR code for the final hosted HTTPS URL using a trusted QR generator. The scanner opens a scanned URL when supported.
- **Wait-time precision:** the displayed estimate uses a simple average-based estimate. Actual waits vary by doctor, urgency, breaks, and consultation duration. A production hospital should configure per-department service times and urgent-case policy.
- **Queue integrity:** for a production launch, implement token allocation through a trusted backend/Cloud Function with stricter transaction and validation logic. The included rules protect admin operations, but a real deployment should review token-number allocation and patient data handling with a qualified developer.
- **Privacy/security:** use synthetic data for a college presentation. Do not enter real patient health details until the hospital's privacy, security, and operational requirements have been reviewed.

## Files

- `index.html` — patient portal, booking and live tracking
- `login.html` — patient sign-in and account creation
- `admin.html` — restricted administration console
- `app.js`, `auth.js`, `admin.js` — website logic
- `style.css` — responsive purple-and-teal styling
- `firebase-config.js` — Firebase web app configuration placeholder
- `firestore.rules` — starter access rules
