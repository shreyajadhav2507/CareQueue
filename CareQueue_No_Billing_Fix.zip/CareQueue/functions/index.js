const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');

initializeApp();
const db = getFirestore();
const ALLOWED_DEPARTMENTS = new Set([
  'General Medicine', 'Cardiology', 'Paediatrics', 'Dermatology', 'Orthopaedics', 'ENT'
]);
const ALLOWED_VISIT_TYPES = new Set(['Regular consultation', 'Follow-up', 'Urgent review']);

function safeId(value) {
  return value.replace(/[^a-z0-9]/gi, '_');
}

exports.bookToken = onCall({ region: 'us-central1', enforceAppCheck: false }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Please sign in before booking a token.');
  const uid = request.auth.uid;
  const patientName = typeof request.data?.patientName === 'string' ? request.data.patientName.trim() : '';
  const department = typeof request.data?.department === 'string' ? request.data.department : '';
  const visitType = typeof request.data?.visitType === 'string' ? request.data.visitType : '';

  if (!patientName || patientName.length > 80) throw new HttpsError('invalid-argument', 'Enter a patient name (maximum 80 characters).');
  if (!ALLOWED_DEPARTMENTS.has(department)) throw new HttpsError('invalid-argument', 'Choose a valid hospital department.');
  if (!ALLOWED_VISIT_TYPES.has(visitType)) throw new HttpsError('invalid-argument', 'Choose a valid visit type.');

  const counterRef = db.collection('queueCounters').doc(safeId(department));
  const tokenRef = db.collection('tokens').doc();
  const publicRef = db.collection('queuePublic').doc(tokenRef.id);
  const tokenNumber = await db.runTransaction(async (tx) => {
    const counterSnap = await tx.get(counterRef);
    const last = counterSnap.exists && Number.isInteger(counterSnap.data().lastNumber) ? counterSnap.data().lastNumber : 0;
    const next = last + 1;
    const tokenLabel = `CQ-${String(next).padStart(3, '0')}`;
    const now = FieldValue.serverTimestamp();
    tx.set(counterRef, { lastNumber: next, department, updatedAt: now }, { merge: true });
    tx.set(tokenRef, {
      uid, patientName, department, visitType,
      tokenNumber: next, tokenLabel, status: 'waiting',
      createdAt: now, serviceMinutes: 10
    });
    tx.set(publicRef, {
      department, tokenNumber: next, tokenLabel,
      status: 'waiting', createdAt: now
    });
    return next;
  });
  return { tokenNumber, tokenLabel: `CQ-${String(tokenNumber).padStart(3, '0')}`, tokenId: tokenRef.id };
});
